# Welcome to the Temple Dissertation Template
# adapted by Peyton Coleman from the DissertateUSU template by Tyson Stanley


# Run the following script to install all necessary packages. 
# Simply highlight the following script press the "run" button in the 
# upper right hand corner of the script page.

install.packages(c("tinytex","remotes"))
library(tinytex)
library(remotes)
remotes::install_github("tysonstanley/dissertateUSU")
library(dissertateUSU)
